import UIKit
//data model of the app
struct PhotoInfo: Codable {
    var title: String
    var url: String
    var copyright: String?
    var description: String
    enum CodingKeys: String, CodingKey {
        case title
        case url
        case copyright
        case description = "explanation"
    }
}

var urlComponents = URLComponents(string:"https://api.nasa.gov/planetary/apod")!

urlComponents.queryItems = [
    "api_key" : "NReoYlwTjaapQ3AEHc91CfwdgklPdTStx71k63Kn",
    "date" : "2024-04-14"
].map{
    URLQueryItem(name: $0.key, value: $0.value)
}

Task{
    let(data,response) = try await URLSession.shared.data(from: urlComponents.url!)
    let jsondecoder = JSONDecoder()
    if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode==200{
        //        if let stringData = String(data: data, encoding: .utf8){
        //            print(stringData)aa
        //        }
        
        if let photoInfoJson = try? jsondecoder.decode(PhotoInfo.self, from: data){
            //try if it is typically trying to get converted
            print(photoInfoJson)
        }
    }
}
